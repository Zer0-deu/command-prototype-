# **App Name**: fps unlocker

## Core Features:

- Neural Optimization Architect: An AI tool that evaluates over 250 hardware performance metrics and uses reasoning to decide which specific system-level FPS boosts and kernel parameters to apply dynamically.
- Fluid Glass Command Center: A high-fidelity dashboard featuring interactive liquid glass shaders that react to motion, visualizing real-time frame pacing, VSync pulses, and GPU load.
- Shizuku System Override: Utilizes elevated shell permissions to force peak refresh rates up to 165Hz, adjust process cgroups for 'top-app' priority, and disable system-wide animation overhead.
- Adaptive Prisma Profiles: Cloud-synced optimization presets for specific games and hardware, featuring deep support for all versions of titles like PUBG Mobile, COD Mobile, and Genshin Impact.
- Atmospheric Sync Tool: An AI tool that uses audio-reasoning to analyze ambient rhythm and intensity, intelligently matching the screen's refresh cycle and strobe patterns to the environment.
- Predictive Thermal Guard: An AI tool that uses reasoning to forecast thermal throttling 10 seconds ahead and preemptively downscale render quality to prevent sudden frame drops.
- Low-Latency Render Bridge: Implements Swappy frame pacing and NDK-based hot loops to decouple simulation tick rates from render rates, ensuring 120Hz+ smoothness even under thermal load.
- Universal Game Version Nexus: An advanced version-agnostic detection engine that applies tailored performance patches to all regional variants of BGMI, PUBG, Free Fire, Fortnite, Genshin Impact, and more.

## Style Guidelines:

- Primary Color: Vibrant Sapphire (#4784EB) for a sleek, high-tech professional aesthetic.
- Background: Deep Obsidian (#10141A) with desaturated tones to enhance the visibility of glass-morphic elements.
- A borderless, full-bleed interface utilizing the Liquid Glass effect as a foundational surface material for all interactive panels.
- Headlines in 'Space Grotesk' for a computerized feel; body text in 'Inter' for machined, objective clarity.
- Custom minimalist 'Apex' branding icons featuring translucent layers and refractive edges to mimic the physical properties of glass.
- Refractive GLSL-powered transitions that simulate the shifting flow of high-viscosity liquid during view changes.