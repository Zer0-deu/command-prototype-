
"use client";

import React, { useState, useEffect } from 'react';
import { Sidebar } from '@/components/Sidebar';
import { HomeTab } from '@/components/HomeTab';
import { GamesTab } from '@/components/GamesTab';
import { GfxTab } from '@/components/GfxTab';
import { BoosterTab } from '@/components/BoosterTab';
import { NetworkTab } from '@/components/NetworkTab';
import { InGameOverlay } from '@/components/InGameOverlay';
import { DeepScan } from '@/components/DeepScan';
import { 
  User as UserIcon, 
  Fingerprint,
  Info,
  Activity
} from 'lucide-react';
import { useUser } from '@/firebase';
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Badge } from '@/components/ui/badge';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import Image from 'next/image';
import imageData from '@/app/lib/placeholder-images.json';

export type DeviceTier = 'low' | 'mid' | 'high';

export default function Home() {
  const [activeTab, setActiveTab] = useState('home');
  const [showSplash, setShowSplash] = useState(true);
  const [isScanning, setIsScanning] = useState(false);
  const [hasScanned, setHasScanned] = useState(false);
  const [deviceTier, setDeviceTier] = useState<DeviceTier>('mid');
  const { user, loading } = useUser();

  useEffect(() => {
    const timer = setTimeout(() => {
      setShowSplash(false);
      setIsScanning(true);
    }, 1200);
    return () => clearTimeout(timer);
  }, []);

  const handleScanComplete = (tier: DeviceTier) => {
    setDeviceTier(tier);
    setIsScanning(false);
    setHasScanned(true);
  };

  if (showSplash || loading) {
    return (
      <div className="fixed inset-0 z-[9999] flex flex-col items-center justify-center bg-background overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-primary/15 via-transparent to-transparent animate-cyber-pulse" />
        <div className="relative group flex flex-col items-center gap-8">
          <div className="relative w-36 h-36 flex items-center justify-center">
            <div className="absolute inset-0 border-[3px] border-primary/20 rounded-full animate-spin [animation-duration:4s]" />
            <div className="relative w-24 h-24 animate-pulse drop-shadow-[0_0_30px_rgba(6,182,212,0.9)]">
              <Image 
                src={imageData['command-logo'].url}
                alt="COMMAND"
                fill
                className="object-contain"
                data-ai-hint={imageData['command-logo'].hint}
              />
            </div>
          </div>
          <div className="text-center space-y-3">
            <h1 className="text-6xl font-headline font-black tracking-tighter italic uppercase text-white scale-110 drop-shadow-[0_0_15px_rgba(255,255,255,0.2)]">
              COMMAND
            </h1>
            <p className="text-[11px] font-black tracking-[0.8em] uppercase text-primary/70">Performance Engine v4.5</p>
          </div>
        </div>
      </div>
    );
  }

  if (isScanning && !hasScanned) {
    return <DeepScan onComplete={handleScanComplete} />;
  }

  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground relative overflow-x-hidden selection:bg-primary/40">
      <header className="p-5 flex flex-col gap-2 sticky top-0 bg-background/80 backdrop-blur-3xl z-40 border-b border-white/5 shadow-xl shadow-black/20">
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-3 group cursor-pointer" onClick={() => setActiveTab('home')}>
             <div className="w-9 h-9 relative flex items-center justify-center transition-all group-hover:scale-110 group-active:scale-95">
               <Image 
                  src={imageData['command-logo'].url}
                  alt="COMMAND"
                  fill
                  className="object-contain drop-shadow-[0_0_8px_rgba(6,182,212,0.5)]"
                  data-ai-hint={imageData['command-logo'].hint}
                />
             </div>
             <div className="flex flex-col">
               <h1 className="text-2xl font-headline font-black tracking-tighter uppercase text-white italic leading-tight">
                {activeTab === 'home' && 'COMMAND'}
                {activeTab === 'games' && 'LIBRARY'}
                {activeTab === 'gfx' && 'GRAPHICS'}
                {activeTab === 'net' && 'NETWORK'}
                {activeTab === 'flux' && 'RESOURCES'}
              </h1>
              <p className="text-[7px] font-black tracking-[0.5em] text-primary/60 uppercase -mt-0.5">CORE_ENGINE</p>
             </div>
          </div>
          <div className="flex gap-2.5 items-center">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Badge variant="outline" className="text-[8px] font-black border-primary/30 text-primary bg-primary/10 px-2.5 py-1 cursor-help tracking-widest shadow-[0_0_10px_rgba(6,182,212,0.2)]">
                    {deviceTier.toUpperCase()}_UNIT
                  </Badge>
                </TooltipTrigger>
                <TooltipContent className="bg-neutral-900 border-white/10 text-[9px] text-primary">
                  Hardware Signature Verified
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
            
            <Dialog>
              <DialogTrigger asChild>
                <button className="w-10 h-10 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center hover:bg-primary/20 hover:border-primary/40 transition-all active:scale-90 relative group shadow-inner">
                  <UserIcon className="w-4.5 h-4.5 text-primary drop-shadow-[0_0_5px_rgba(6,182,212,0.5)]" />
                  <div className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-emerald-500 rounded-full border-2 border-background animate-pulse shadow-[0_0_10px_#10b981]" />
                </button>
              </DialogTrigger>
              <DialogContent className="bg-background/98 border-white/10 text-white max-w-[95vw] w-[400px] rounded-[2.5rem] shadow-[0_0_60px_rgba(6,182,212,0.25)] p-8">
                <DialogHeader className="mb-6">
                  <DialogTitle className="uppercase font-black font-headline tracking-widest italic text-primary text-3xl text-center">User Profile</DialogTitle>
                  <DialogDescription className="text-[10px] uppercase text-center opacity-50 tracking-[0.6em] font-black mt-2">Identity Verification Successful</DialogDescription>
                </DialogHeader>
                <div className="space-y-6">
                  <div className="flex items-center gap-5 p-6 bg-white/5 rounded-[2rem] border border-white/10 shadow-inner">
                    <div className="w-16 h-16 rounded-2xl bg-primary/20 flex items-center justify-center border border-primary/40 shadow-[0_0_20px_rgba(6,182,212,0.3)] shrink-0">
                      <Fingerprint className="w-8 h-8 text-primary" />
                    </div>
                    <div className="overflow-hidden">
                      <p className="text-[10px] text-primary uppercase font-black tracking-[0.3em] mb-1.5 italic">Authorized Unit</p>
                      <p className="text-base font-bold truncate tracking-tight">{user?.email}</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4 p-5 bg-accent/10 border border-accent/20 rounded-[1.5rem]">
                    <Info className="w-5 h-5 text-accent shrink-0 mt-0.5" />
                    <p className="text-[10px] text-accent/90 italic leading-relaxed uppercase tracking-wider font-bold">
                      Performance overlays active. System integrity monitored by Core Guardian.
                    </p>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>
        <div className="flex items-center gap-2.5 px-1.5 overflow-hidden">
           <Activity className="w-3.5 h-3.5 text-emerald-500 animate-pulse" />
           <p className="text-muted-foreground text-[9px] uppercase tracking-[0.4em] font-black opacity-90 truncate italic">
            {activeTab === 'home' && 'System Core Synchronized'}
            {activeTab === 'games' && 'Library Analysis Active'}
            {activeTab === 'gfx' && 'Graphic Engine Bridge Stable'}
            {activeTab === 'net' && 'Connection Stabilizer Locked'}
            {activeTab === 'flux' && 'Resource Manager Optimized'}
          </p>
        </div>
      </header>

      <main className="flex-1 overflow-y-auto px-5 py-8 pb-32 custom-scrollbar">
        <div className="max-w-md mx-auto space-y-10">
          {activeTab === 'home' && <HomeTab tier={deviceTier} />}
          {activeTab === 'games' && <GamesTab tier={deviceTier} />}
          {activeTab === 'gfx' && <GfxTab tier={deviceTier} />}
          {activeTab === 'net' && <NetworkTab />}
          {activeTab === 'flux' && <BoosterTab />}
        </div>
      </main>

      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />
      <InGameOverlay />
    </div>
  );
}
