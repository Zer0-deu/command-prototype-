
import type { Metadata } from 'next';
import './globals.css';
import { FirebaseClientProvider } from '@/firebase/client-provider';

export const metadata: Metadata = {
  title: 'COMMAND | Pro Gaming Performance',
  description: 'Professional hardware optimization and graphic overrides for competitive mobile gaming.',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Space+Grotesk:wght@500;600;700&display=swap" rel="stylesheet" />
      </head>
      <body className="font-body antialiased min-h-screen bg-neutral-950 flex justify-center" suppressHydrationWarning>
        <div className="w-full max-w-md bg-background min-h-screen shadow-2xl relative overflow-hidden border-x border-white/5">
          <FirebaseClientProvider>
            {children}
          </FirebaseClientProvider>
        </div>
      </body>
    </html>
  );
}
