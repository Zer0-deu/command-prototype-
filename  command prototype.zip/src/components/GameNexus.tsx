
"use client";

import React, { useState } from 'react';
import { LiquidGlassCard } from './LiquidGlassCard';
import { Package, Globe, Smartphone, Download, Check, Loader2, ChevronDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Image from 'next/image';
import imageData from '@/app/lib/placeholder-images.json';
import { cn } from '@/lib/utils';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const GAMES = [
  { 
    id: 'pubg', 
    name: 'PUBG Mobile', 
    image: imageData['pubg-mobile'],
    versions: [
      { label: 'Global', pkg: 'com.tencent.ig' },
      { label: 'Korea', pkg: 'com.pubg.krmobile' },
      { label: 'Vietnam', pkg: 'com.vng.pubgmobile' },
      { label: 'Taiwan', pkg: 'com.repubg.krmobile' },
      { label: 'India (BGMI)', pkg: 'com.pubg.imobile' }
    ]
  },
  { 
    id: 'cod', 
    name: 'COD Mobile', 
    image: imageData['cod-mobile'],
    versions: [
      { label: 'Global', pkg: 'com.activision.callofduty.shooter' },
      { label: 'Garena', pkg: 'com.garena.game.codm' },
      { label: 'Chinese', pkg: 'com.tencent.tmgp.cod' }
    ]
  },
  { 
    id: 'df', 
    name: 'Delta Force', 
    image: imageData['delta-force'],
    versions: [
      { label: 'Global', pkg: 'com.proxima.dfm' },
      { label: 'Chinese', pkg: 'com.tencent.tmgp.df' },
      { label: 'Garena', pkg: 'com.garena.game.dfm' }
    ]
  },
  { 
    id: 'ff', 
    name: 'Free Fire', 
    image: imageData['free-fire'],
    versions: [
      { label: 'Garena', pkg: 'com.dts.freefireth' },
      { label: 'Max', pkg: 'com.dts.freefiremax' }
    ]
  }
];

export const GameNexus = () => {
  const [selectedGame, setSelectedGame] = useState(GAMES[0]);
  const [versionIdx, setVersionIdx] = useState(0);
  const [isPatching, setIsPatching] = useState(false);
  const [isPatched, setIsPatched] = useState(false);

  const handlePatch = () => {
    setIsPatching(true);
    setTimeout(() => {
      setIsPatching(false);
      setIsPatched(true);
      setTimeout(() => setIsPatched(false), 3000);
    }, 2000);
  };

  const currentPkg = selectedGame.versions[versionIdx]?.pkg || 'unknown.package';
  const currentLabel = selectedGame.versions[versionIdx]?.label || 'Select';

  return (
    <LiquidGlassCard className="h-full flex flex-col p-6 sm:p-8 overflow-hidden">
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-primary/20 rounded-xl">
            <Package className="w-6 h-6 sm:w-8 sm:h-8 text-primary" />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-headline font-bold uppercase italic tracking-tighter">Game Nexus</h2>
            <p className="text-[9px] text-muted-foreground uppercase font-black tracking-widest opacity-60">Universal Version Probe</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-3 mb-6">
        {GAMES.map((game) => (
          <button
            key={game.id}
            onClick={() => {
              setSelectedGame(game);
              setVersionIdx(0);
            }}
            className={cn(
              "relative aspect-square rounded-xl overflow-hidden border-2 transition-all",
              selectedGame.id === game.id ? "border-primary scale-95 shadow-[0_0_20px_rgba(6,182,212,0.3)]" : "border-transparent opacity-40 hover:opacity-100"
            )}
          >
            <Image 
              src={game.image.url} 
              alt={game.name} 
              fill 
              className="object-cover"
              data-ai-hint={game.image.hint}
            />
            <div className="absolute inset-0 bg-black/60 flex items-center justify-center p-1 text-center">
              <span className="text-[7px] font-black uppercase leading-tight italic">{game.name}</span>
            </div>
          </button>
        ))}
      </div>

      <div className="flex-1 flex flex-col gap-4">
        <div className="space-y-2">
          <label className="text-[9px] text-primary uppercase font-black tracking-widest italic ml-1">Target Version</label>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="outline"
                className="w-full justify-between h-12 bg-white/5 border-white/10 text-[9px] font-black tracking-[0.2em] uppercase italic hover:bg-white/10"
              >
                <span className="flex items-center gap-2">
                  <Globe className="w-3 h-3 text-primary" />
                  {currentLabel}
                </span>
                <ChevronDown className="w-3 h-3 opacity-50" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-[calc(100vw-4rem)] max-w-[340px] bg-neutral-900 border-white/10">
              {selectedGame.versions.map((v, i) => (
                <DropdownMenuItem 
                  key={v.label} 
                  onClick={() => setVersionIdx(i)}
                  className="flex flex-col items-start gap-1 py-3 px-4 border-b border-white/5 last:border-none cursor-pointer"
                >
                  <span className="text-[10px] font-black tracking-widest uppercase text-white">{v.label}</span>
                  <span className="text-[7px] font-mono text-muted-foreground">{v.pkg}</span>
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        <div className="mt-auto space-y-4">
          <div className="p-4 bg-black/40 rounded-2xl flex items-center gap-4 border border-white/5">
            <div className="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center border border-primary/20">
              <Smartphone className="text-primary w-5 h-5" />
            </div>
            <div className="overflow-hidden">
              <p className="text-[7px] font-black text-primary uppercase tracking-widest mb-0.5">Package Identity</p>
              <p className="text-[9px] font-bold truncate italic uppercase text-white">{currentPkg}</p>
            </div>
          </div>
          
          <Button 
            onClick={handlePatch} 
            disabled={isPatching}
            className="w-full bg-primary hover:bg-primary/80 h-12 text-background font-black tracking-[0.3em] text-[10px] shadow-[0_8px_25px_rgba(6,182,212,0.3)] rounded-2xl italic uppercase"
          >
            {isPatching ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                NEURAL_PROBE...
              </>
            ) : isPatched ? (
              <>
                <Check className="w-4 h-4 mr-2" />
                HANDSHAKE_OK
              </>
            ) : (
              <>
                <Download className="w-4 h-4 mr-2" />
                SYNC NEURAL LINK
              </>
            )}
          </Button>
        </div>
      </div>
    </LiquidGlassCard>
  );
};
