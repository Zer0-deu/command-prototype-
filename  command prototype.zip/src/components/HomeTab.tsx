
"use client";

import React, { useState, useEffect } from 'react';
import { LiquidGlassCard } from './LiquidGlassCard';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Smartphone, 
  ShieldCheck, 
  Cpu,
  Loader2,
  Edit2,
  Activity,
  Flame,
  Zap,
  Lock,
  Wifi,
  Thermometer
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useUser, useFirestore, useDoc, errorEmitter, FirestorePermissionError, useMemoFirebase } from '@/firebase';
import { doc, setDoc } from 'firebase/firestore';
import { CommandCenter } from './CommandCenter';
import { useToast } from '@/hooks/use-toast';
import { Input } from '@/components/ui/input';
import Image from 'next/image';
import imageData from '@/app/lib/placeholder-images.json';
import { DeviceTier } from '@/app/page';

const FPS_OPTIONS = [60, 90, 120, 144, 165];

interface HomeTabProps {
  tier: DeviceTier;
}

export const HomeTab = ({ tier }: HomeTabProps) => {
  const { user } = useUser();
  const firestore = useFirestore();
  const { toast } = useToast();
  
  const userDocRef = useMemoFirebase(() => (user && firestore ? doc(firestore, 'users', user.uid) : null), [user, firestore]);
  const { data: userProfile } = useDoc(userDocRef);

  const [currentHz, setCurrentHz] = useState(60);
  const [targetHz, setTargetHz] = useState(tier === 'low' ? 60 : tier === 'mid' ? 90 : 120);
  const [isApplying, setIsApplying] = useState(false);
  const [logs, setLogs] = useState<string[]>([]);
  const [deviceName, setDeviceName] = useState("COMMAND_UNIT_01");
  const [isEditingDevice, setIsEditingDevice] = useState(false);

  useEffect(() => {
    if (userProfile?.deviceName) setDeviceName(userProfile.deviceName);
  }, [userProfile]);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentHz(prev => {
        const jitter = (Math.random() - 0.5) * 0.1;
        const base = targetHz || 60;
        return Number((base + jitter).toFixed(1));
      });
    }, 800);
    return () => clearInterval(interval);
  }, [targetHz]);

  const handleApplyBoost = () => {
    setIsApplying(true);
    setLogs([
      "INITIALIZING SYSTEM OVERRIDE...",
      "BYPASSING KERNEL LIMITS...",
      "SETTING REFRESH RATE: " + targetHz + "HZ",
      "OPTIMIZATION APPLIED"
    ]);

    const data = {
      targetHz,
      lastUpdated: new Date().toISOString(),
      tier,
      graphicsMode: (tier === 'low' || tier === 'mid') ? 'HD' : 'HDR'
    };

    if (userDocRef) {
      setDoc(userDocRef, data, { merge: true });
      setTimeout(() => {
        setIsApplying(false);
        toast({
          title: "ENGINE SYNCED",
          description: `Refresh rate locked at ${targetHz}Hz.`,
        });
      }, 700);
    }
  };

  const handleSaveDeviceName = () => {
    if (!userDocRef) return;
    setDoc(userDocRef, { deviceName }, { merge: true });
    setIsEditingDevice(false);
    toast({ title: "SIGNATURE UPDATED", description: "Hardware label has been saved." });
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-8 duration-700">
      <div className="flex items-center justify-between px-3">
        <div className="flex items-center gap-3">
           <div className="w-2.5 h-2.5 bg-emerald-500 rounded-full shadow-[0_0_15px_#10b981] animate-pulse" />
           <h2 className="text-[11px] font-black text-primary uppercase tracking-[0.5em] italic">Engine_Active</h2>
        </div>
        <Badge className="text-[9px] bg-primary/20 text-primary border-primary/40 uppercase font-black px-3 py-1 italic tracking-widest shadow-inner">
          {tier.toUpperCase()}_UNIT
        </Badge>
      </div>

      <CommandCenter />

      <LiquidGlassCard className="p-8 sm:p-12 relative group hover:shadow-[0_0_60px_rgba(6,182,212,0.2)] transition-all">
        <div className="absolute top-0 right-0 p-6 opacity-5 transition-opacity pointer-events-none">
          <div className="relative w-28 h-28 rotate-12">
            <Image 
              src={imageData['command-logo'].url}
              alt="COMMAND"
              fill
              className="object-contain"
              data-ai-hint={imageData['command-logo'].hint}
            />
          </div>
        </div>
        
        <div className="flex justify-between items-start mb-10">
          <div>
            <h2 className="text-5xl font-headline font-black italic uppercase tracking-tighter text-white leading-none mb-2 drop-shadow-[0_0_10px_rgba(255,255,255,0.1)]">COMMAND</h2>
            <p className="text-[10px] text-primary/70 uppercase tracking-[0.5em] font-black italic">Hardware Performance Core</p>
          </div>
          <div className="p-3 rounded-2xl border bg-primary/20 border-primary/40 text-primary shadow-lg shadow-primary/20">
            <Cpu className="w-8 h-8" />
          </div>
        </div>

        <div className="flex flex-col items-center justify-center py-12 relative mb-10 group/orb">
          <div className="text-8xl sm:text-9xl font-headline font-black text-white tracking-tighter flex items-baseline z-10 italic drop-shadow-[0_0_30px_rgba(255,255,255,0.2)]">
            {currentHz}
            <span className="text-3xl font-black text-primary ml-3 not-italic opacity-80 tracking-normal">FPS</span>
          </div>
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
             <div className="w-64 h-64 border-2 border-primary/10 rounded-full animate-spin [animation-duration:20s]" />
          </div>
        </div>

        <div className="space-y-8">
          <div className="flex flex-wrap justify-center gap-3">
            {tier === 'high' ? (
              FPS_OPTIONS.map(hz => (
                <button
                  key={hz}
                  onClick={() => setTargetHz(hz)}
                  className={cn(
                    "px-6 py-4 rounded-[1.5rem] border-2 font-headline font-black text-lg transition-all active:scale-95 shadow-lg",
                    targetHz === hz 
                      ? "bg-primary border-primary text-background shadow-[0_0_25px_rgba(6,182,212,0.5)] scale-105" 
                      : "bg-white/5 border-white/10 text-muted-foreground hover:border-primary/40 hover:text-white"
                  )}
                >
                  {hz}
                </button>
              ))
            ) : (
              <div className="w-full p-6 bg-white/5 border border-primary/20 rounded-[2rem] text-center">
                <p className="text-[10px] text-primary font-black uppercase tracking-[0.4em] mb-2 italic">Performance Lock</p>
                <h3 className="text-2xl font-headline font-black text-white italic">{targetHz} FPS STABILIZED</h3>
                <p className="text-[8px] text-muted-foreground uppercase tracking-widest mt-2">Target rate auto-assigned for {tier}-end hardware</p>
              </div>
            )}
          </div>
          
          <Button 
            onClick={handleApplyBoost}
            disabled={isApplying}
            className="w-full h-20 text-[13px] font-black tracking-[0.5em] bg-primary hover:bg-primary/90 text-background rounded-[2rem] transition-all uppercase italic shadow-[0_15px_30px_rgba(6,182,212,0.4)]"
          >
            {isApplying ? <Loader2 className="w-6 h-6 animate-spin" /> : "APPLY SYSTEM BOOST"}
          </Button>

          <div className="bg-black/60 rounded-[1.5rem] p-6 font-mono text-[10px] text-primary/80 border border-primary/20 min-h-[110px] shadow-inner leading-relaxed overflow-hidden italic">
            {logs.length === 0 && (
              <div className="flex flex-col gap-3 opacity-40">
                <p className="flex items-center gap-3"><Activity className="w-4 h-4 text-primary" /> Architecture: {tier.toUpperCase()}</p>
                <div className="h-px bg-white/5 w-full" />
                <p className="text-[8px] uppercase tracking-[0.2em]">Hardware signature: {deviceName}</p>
              </div>
            )}
            {logs.map((log, i) => (
              <div key={i} className="flex gap-3 mb-1 animate-in slide-in-from-left-4 fade-in duration-300">
                <span className="text-accent font-black">»</span>
                {log}
              </div>
            ))}
          </div>
        </div>
      </LiquidGlassCard>

      <div className="grid grid-cols-2 gap-5">
        <LiquidGlassCard className="p-7 flex flex-col justify-between h-48 group hover:bg-primary/5 transition-all">
          <div>
            <div className="flex items-center gap-4 mb-4">
              <div className="p-2.5 bg-primary/20 rounded-xl group-hover:bg-primary/30 transition-all shadow-[0_0_15px_rgba(6,182,212,0.2)]">
                <ShieldCheck className="w-6 h-6 text-primary" />
              </div>
              <span className="text-[11px] font-black uppercase tracking-[0.3em] text-white italic">Security</span>
            </div>
            <p className="text-[9px] text-muted-foreground uppercase leading-relaxed font-bold tracking-tighter">System permission and security status.</p>
          </div>
          <Badge className="bg-emerald-500/10 text-emerald-400 border-emerald-500/20 text-center py-2 rounded-xl text-[9px] font-black italic uppercase">VERIFIED</Badge>
        </LiquidGlassCard>

        <LiquidGlassCard className="p-7 flex flex-col justify-between h-48 group hover:bg-accent/5 transition-all">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-4">
              <div className="p-2.5 bg-accent/20 rounded-xl group-hover:bg-accent/30 transition-all shadow-[0_0_15px_rgba(168,85,247,0.2)]">
                <Smartphone className="w-6 h-6 text-accent" />
              </div>
              <span className="text-[11px] font-black uppercase tracking-[0.3em] text-white italic">Identity</span>
            </div>
            <button onClick={() => setIsEditingDevice(!isEditingDevice)} className="p-2 hover:bg-white/10 rounded-xl transition-all">
              <Edit2 className="w-4 h-4 text-accent opacity-60 hover:opacity-100" />
            </button>
          </div>
          
          <div className="flex-1 flex flex-col justify-center overflow-hidden">
            {isEditingDevice ? (
              <div className="flex gap-2.5">
                <Input 
                  value={deviceName} 
                  onChange={(e) => setDeviceName(e.target.value)}
                  className="h-10 text-[10px] bg-black/50 border-accent/40 rounded-xl px-4 font-bold tracking-tight italic"
                  autoFocus
                />
                <Button size="sm" className="h-10 px-4 text-[10px] bg-accent hover:bg-accent/80 font-black rounded-xl italic" onClick={handleSaveDeviceName}>Set</Button>
              </div>
            ) : (
              <div className="overflow-hidden animate-in fade-in zoom-in-95 duration-500">
                <p className="text-base font-black text-accent uppercase italic truncate tracking-tighter drop-shadow-[0_0_10px_rgba(168,85,247,0.4)]">{deviceName}</p>
                <div className="flex items-center gap-2.5 mt-2.5">
                  <Flame className="w-3.5 h-3.5 text-emerald-500 animate-pulse shadow-[0_0_8px_#10b981]" />
                  <span className="text-[8px] text-muted-foreground uppercase font-black tracking-[0.3em] italic">Telemetry Stable</span>
                </div>
              </div>
            )}
          </div>
        </LiquidGlassCard>
      </div>

      <div className="grid grid-cols-3 gap-4">
        {[
          { icon: Thermometer, label: 'Temp', value: '38°C', color: 'text-rose-400' },
          { icon: Wifi, label: 'Net', value: '32ms', color: 'text-emerald-400' },
          { icon: Lock, label: 'Override', value: 'Active', color: 'text-primary' }
        ].map((item, i) => (
          <LiquidGlassCard key={i} className="p-4 text-center space-y-2 border-white/5">
            <item.icon className={cn("w-4 h-4 mx-auto", item.color)} />
            <p className="text-[7px] text-muted-foreground uppercase font-black tracking-widest">{item.label}</p>
            <p className={cn("text-[10px] font-black italic", item.color)}>{item.value}</p>
          </LiquidGlassCard>
        ))}
      </div>
    </div>
  );
};
