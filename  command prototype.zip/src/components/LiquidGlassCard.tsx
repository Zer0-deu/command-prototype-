import React from 'react';
import { cn } from '@/lib/utils';

interface LiquidGlassCardProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode;
  variant?: 'default' | 'primary' | 'muted' | 'accent';
}

export const LiquidGlassCard = ({ children, className, variant = 'default', ...props }: LiquidGlassCardProps) => {
  const variantClasses = {
    default: 'bg-white/5 border-white/10 shadow-[0_0_20px_rgba(0,0,0,0.5)]',
    primary: 'bg-primary/5 border-primary/20 shadow-[0_0_20px_rgba(6,182,212,0.1)]',
    accent: 'bg-accent/5 border-accent/20 shadow-[0_0_20px_rgba(168,85,247,0.1)]',
    muted: 'bg-black/40 border-white/5 shadow-inner',
  };

  return (
    <div 
      className={cn(
        "liquid-glass glass-shine group transition-all duration-500 gaming-glow",
        variantClasses[variant],
        className
      )}
      {...props}
    >
      {/* Top highlight line */}
      <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-white/20 to-transparent" />
      
      {/* Corner accents */}
      <div className="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 border-white/10 rounded-tl-xl transition-all group-hover:border-primary/40" />
      <div className="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 border-white/10 rounded-br-xl transition-all group-hover:border-accent/40" />
      
      {children}
    </div>
  );
};
