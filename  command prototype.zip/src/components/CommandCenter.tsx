"use client";

import React, { useEffect, useState, useMemo } from 'react';
import { 
  ResponsiveContainer, 
  Area,
  AreaChart
} from 'recharts';
import { LiquidGlassCard } from './LiquidGlassCard';
import { Activity, Zap } from 'lucide-react';

const generateData = () => {
  return Array.from({ length: 15 }, (_, i) => ({
    name: i,
    fps: Math.floor(Math.random() * (120 - 110) + 110),
    latency: Math.floor(Math.random() * (8 - 4) + 4),
  }));
};

export const CommandCenter = () => {
  const [data, setData] = useState<{name: number, fps: number, latency: number}[]>([]);

  useEffect(() => {
    setData(generateData());

    const interval = setInterval(() => {
      setData(prev => {
        if (prev.length === 0) return generateData();
        return [...prev.slice(1), {
          name: prev.length,
          fps: Math.floor(Math.random() * (122 - 118) + 118),
          latency: Math.floor(Math.random() * (7 - 5) + 5),
        }];
      });
    }, 1500); // Reduced frequency for lower CPU overhead
    return () => clearInterval(interval);
  }, []);

  if (data.length === 0) return null;

  return (
    <div className="grid grid-cols-2 gap-4">
      <LiquidGlassCard className="p-4 flex flex-col justify-between h-36">
        <div className="flex justify-between items-start">
          <div>
            <p className="text-[8px] text-muted-foreground uppercase tracking-widest font-bold">FPS</p>
            <h3 className="text-2xl font-headline font-bold text-primary">120</h3>
          </div>
          <Activity className="text-primary w-4 h-4" />
        </div>
        <div className="h-12 w-full opacity-50">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={data} margin={{ top: 0, right: 0, left: 0, bottom: 0 }}>
              <Area 
                type="monotone" 
                dataKey="fps" 
                stroke="#06b6d4" 
                fill="#06b6d4" 
                fillOpacity={0.1} 
                strokeWidth={2} 
                isAnimationActive={false} 
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </LiquidGlassCard>

      <LiquidGlassCard className="p-4 flex flex-col justify-between h-36">
        <div className="flex justify-between items-start">
          <div>
            <p className="text-[8px] text-muted-foreground uppercase tracking-widest font-bold">RTT</p>
            <h3 className="text-2xl font-headline font-bold text-emerald-400">4.2<span className="text-[10px] ml-1">MS</span></h3>
          </div>
          <Zap className="text-emerald-400 w-4 h-4" />
        </div>
        <div className="h-12 w-full opacity-50">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={data} margin={{ top: 0, right: 0, left: 0, bottom: 0 }}>
              <Area 
                type="monotone" 
                dataKey="latency" 
                stroke="#10b981" 
                fill="#10b981" 
                fillOpacity={0.1} 
                strokeWidth={2} 
                isAnimationActive={false} 
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </LiquidGlassCard>
    </div>
  );
};
