
"use client";

import React, { useState, useEffect } from 'react';
import { LiquidGlassCard } from './LiquidGlassCard';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Search, 
  Play, 
  Sparkles, 
  Zap,
  Box,
  Flame
} from 'lucide-react';
import Image from 'next/image';
import imageData from '@/app/lib/placeholder-images.json';
import { cn } from '@/lib/utils';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { DeviceTier } from '@/app/page';

const SUPPORTED_GAMES = [
  { 
    id: 'pubg', 
    name: 'PUBG Mobile', 
    versions: [
      { label: 'Global', pkg: 'com.tencent.ig', image: imageData['pubg-global'] },
      { label: 'India (BGMI)', pkg: 'com.pubg.imobile', image: imageData['pubg-in'] }
    ]
  },
  { 
    id: 'codm', 
    name: 'COD Mobile', 
    versions: [
      { label: 'Global', pkg: 'com.activision.callofduty.shooter', image: imageData['cod-global'] },
      { label: 'Garena', pkg: 'com.garena.game.codm', image: imageData['cod-garena'] }
    ]
  },
  { 
    id: 'df', 
    name: 'Delta Force', 
    versions: [
      { label: 'Global', pkg: 'com.proxima.dfm', image: imageData['delta-global'] }
    ]
  },
  { 
    id: 'ff', 
    name: 'Free Fire', 
    versions: [
      { label: 'Garena', pkg: 'com.dts.freefireth', image: imageData['free-fire'] }
    ]
  },
  { 
    id: 'ab', 
    name: 'Arena Breakout', 
    versions: [
      { label: 'Global', pkg: 'com.madhead.ab', image: imageData['arena-breakout'] }
    ]
  },
  { 
    id: 'fn', 
    name: 'Fortnite', 
    versions: [{ label: 'Global', pkg: 'com.epicgames.fortnite', image: imageData['fortnite'] }]
  },
  { 
    id: 'wzm', 
    name: 'Warzone Mobile', 
    versions: [{ label: 'Global', pkg: 'com.activision.callofduty.warzone', image: imageData['warzone'] }]
  }
];

interface GamesTabProps {
  tier: DeviceTier;
}

export const GamesTab = ({ tier }: GamesTabProps) => {
  const [search, setSearch] = useState('');
  const [launchingGame, setLaunchingGame] = useState<null | any>(null);
  const [launchStep, setLaunchStep] = useState(0);
  const [selectedVersions, setSelectedVersions] = useState<Record<string, number>>({});
  const [potentialBoosts, setPotentialBoosts] = useState<Record<string, number>>({});

  useEffect(() => {
    const interval = setInterval(() => {
      const base = tier === 'low' ? 12 : tier === 'mid' ? 24 : 45;
      const newBoosts: Record<string, number> = {};
      SUPPORTED_GAMES.forEach(g => {
        newBoosts[g.id] = base + Math.floor(Math.random() * 8);
      });
      setPotentialBoosts(newBoosts);
    }, 3000);
    return () => clearInterval(interval);
  }, [tier]);

  const handleLaunch = (game: any) => {
    const versionIdx = selectedVersions[game.id] || 0;
    const version = game.versions[versionIdx];
    
    setLaunchingGame({ ...game, currentVersion: version });
    setLaunchStep(0);
    
    let currentStep = 0;
    const stepsCount = 10;
    const interval = setInterval(() => {
      currentStep++;
      setLaunchStep(currentStep);
      if (currentStep >= stepsCount) {
        clearInterval(interval);
        setTimeout(() => setLaunchingGame(null), 1500);
      }
    }, 350);
  };

  const filteredGames = SUPPORTED_GAMES.filter(g => 
    g.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-8 pb-32 animate-in fade-in slide-in-from-right-12 duration-700">
      <div className="relative group">
        <Search className="absolute left-6 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground group-focus-within:text-primary transition-all duration-500 z-10" />
        <Input 
          placeholder="SEARCH GAME LIBRARY..." 
          className="pl-16 h-16 sm:h-20 bg-white/5 border-white/10 text-[11px] font-black tracking-[0.4em] rounded-[1.5rem] focus:ring-primary/40 focus:border-primary border-2 transition-all italic"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      <div className="grid grid-cols-2 gap-5 sm:gap-6">
        {filteredGames.map((game, idx) => {
          const versionIdx = selectedVersions[game.id] || 0;
          const currentVersion = game.versions[versionIdx];
          const displayImage = currentVersion.image || game.versions[0].image;
          const boost = potentialBoosts[game.id] || 0;

          return (
            <LiquidGlassCard 
              key={game.id} 
              className="group overflow-hidden flex flex-col active:scale-[0.96] transition-all duration-500 hover:shadow-[0_0_40px_rgba(6,182,212,0.2)]"
            >
              <div className="relative aspect-square w-full overflow-hidden">
                <Image 
                  src={displayImage.url} 
                  alt={game.name} 
                  fill 
                  className="object-cover group-hover:scale-110 transition-transform duration-1000"
                  data-ai-hint={displayImage.hint}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/30 to-transparent" />
                
                <div className="absolute top-3 right-3">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="sm" className="h-8 px-3 bg-black/70 backdrop-blur-md border border-white/10 text-[8px] font-black tracking-widest text-primary hover:text-white rounded-full shadow-lg">
                        {currentVersion.label}
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent className="bg-neutral-900 border-white/10 rounded-2xl p-2 min-w-[140px] shadow-2xl">
                      {game.versions.map((v, i) => (
                        <DropdownMenuItem 
                          key={v.label} 
                          onClick={() => setSelectedVersions(prev => ({ ...prev, [game.id]: i }))}
                          className="text-[9px] font-black tracking-[0.2em] uppercase italic text-muted-foreground hover:text-primary hover:bg-white/5 rounded-xl py-2.5 px-4"
                        >
                          {v.label}
                        </DropdownMenuItem>
                      ))}
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>

                <div className="absolute bottom-3 left-3 flex flex-col gap-1.5">
                  <div className="px-2 py-1 bg-primary/20 backdrop-blur-xl rounded-full text-[7px] font-black text-primary uppercase tracking-[0.2em] border border-primary/40 flex items-center gap-2 italic">
                    <Sparkles className="w-2.5 h-2.5 animate-pulse" />
                    {tier === 'high' ? 'HDR_ULTRA' : 'HD_STABLE'}
                  </div>
                  <div className="px-2 py-1 bg-emerald-500/20 backdrop-blur-xl rounded-full text-[7px] font-black text-emerald-400 uppercase tracking-[0.2em] border border-emerald-500/40 flex items-center gap-2 italic animate-in fade-in zoom-in duration-700">
                    <Flame className="w-2.5 h-2.5" />
                    FPS Increase: +{boost}
                  </div>
                </div>
              </div>
              <div className="p-4 space-y-4 bg-gradient-to-b from-transparent to-black/60">
                <div className="space-y-1.5">
                  <h3 className="font-headline font-black text-[12px] truncate uppercase tracking-[0.15em] text-white italic leading-tight">{game.name}</h3>
                  <div className="flex items-center gap-2">
                    <Box className="w-2.5 h-2.5 text-primary/40" />
                    <p className="text-[7px] text-primary/50 font-mono truncate uppercase italic">{currentVersion.pkg}</p>
                  </div>
                </div>
                <Button 
                  onClick={() => handleLaunch(game)}
                  className="w-full h-12 bg-white/5 hover:bg-primary border border-white/10 text-[9px] font-black tracking-[0.3em] text-white group-hover:text-background transition-all duration-500 rounded-[1.25rem] italic"
                >
                  <Play className="w-3.5 h-3.5 mr-2.5 group-hover:fill-current group-hover:animate-pulse" />
                  INITIALIZE_LAUNCH
                </Button>
              </div>
            </LiquidGlassCard>
          );
        })}
      </div>

      {launchingGame && (
        <div className="fixed inset-0 z-[100] bg-background/99 backdrop-blur-3xl flex flex-col items-center justify-center p-6 sm:p-12 animate-in fade-in duration-700 overflow-hidden">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-primary/20 via-accent/10 to-transparent animate-cyber-pulse" />
          
          <div className="relative w-80 h-80 sm:w-96 sm:h-96 flex items-center justify-center">
            <div className="absolute inset-0 border-[4px] border-primary/20 rounded-full animate-spin [animation-duration:25s]" />
            <div className="relative w-40 h-40 rounded-full overflow-hidden border-[3px] border-white/60 shadow-2xl">
              <Image 
                src={launchingGame.currentVersion.image.url} 
                alt={launchingGame.name} 
                fill 
                className="object-cover"
                data-ai-hint={launchingGame.currentVersion.image.hint}
              />
            </div>
          </div>

          <div className="mt-12 text-center space-y-6 w-full max-w-sm z-10 overflow-y-auto px-4 pb-8">
            <h2 className="text-4xl sm:text-5xl font-headline font-black text-white uppercase tracking-tighter italic">
              {launchingGame.name}
            </h2>
            <div className="w-full space-y-3 text-left mt-8 font-mono text-[9px] text-primary/70 bg-black/60 p-6 rounded-[2.5rem] border border-white/10 shadow-2xl backdrop-blur-xl">
              <div className="space-y-2.5 italic">
                {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9].map((idx) => (
                  <div key={idx} className={cn(
                    "flex items-center gap-5 transition-all duration-500",
                    launchStep < idx ? "opacity-0 translate-x-6" : "opacity-100 translate-x-0"
                  )}>
                    <span className={cn(
                      "w-1.5 h-1.5 rounded-full",
                      launchStep > idx ? "bg-emerald-500 shadow-[0_0_10px_#10b981]" : "bg-primary animate-pulse"
                    )} />
                    <span className="tracking-[0.2em] uppercase font-black text-[8px]">
                      {idx === 0 && `CONFIGURING: ${launchingGame.currentVersion.label}`}
                      {idx === 1 && `HARDWARE_LOCK: ${tier.toUpperCase()}_UNIT`}
                      {idx === 2 && `GRAPHICS_IQ: ${tier === 'high' ? 'HDR_MAX' : 'HD_STABLE'}`}
                      {idx === 3 && `FPS_LIMIT: ${tier === 'low' ? '60' : tier === 'mid' ? '90' : '144'}_HZ`}
                      {idx === 4 && "CONNECTION_BRIDGE: ACTIVE"}
                      {idx === 5 && "CPU_SCHEDULER: PERFORMANCE"}
                      {idx === 6 && "HARDWARE_ACCEL: ENGAGED"}
                      {idx === 7 && "NETWORK_STABILIZER: SYNCED"}
                      {idx === 8 && "THERMAL_BYPASS: APPLIED"}
                      {idx === 9 && "SYSTEM_READY: BOOTING"}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
