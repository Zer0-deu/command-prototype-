
"use client";

import React, { useState } from 'react';
import { LiquidGlassCard } from './LiquidGlassCard';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Shield, Battery, Zap, Flame, Terminal, Lock, Loader2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useUser, useFirestore } from '@/firebase';
import { doc, setDoc } from 'firebase/firestore';
import { DeviceTier } from '@/app/page';

const GFX_PROFILES = [
  { id: 'battery', name: 'Power Save', icon: Battery, graphics: 'Smooth', fps: 'High', color: 'text-emerald-400' },
  { id: 'balanced', name: 'Balanced', icon: Shield, graphics: 'Smooth', fps: 'Ultra', color: 'text-blue-400' },
  { id: 'competitive', name: 'Pro Perf', icon: Zap, graphics: 'Smooth', fps: 'Max', color: 'text-primary' },
  { id: 'hdr', name: 'HDR Ultra', icon: Flame, graphics: 'HDR', fps: 'Max', color: 'text-rose-400' },
  { id: 'lagfix', name: 'Stability', icon: Terminal, graphics: 'Smooth', fps: 'Locked', color: 'text-amber-400' }
];

interface GfxTabProps {
  tier: DeviceTier;
}

export const GfxTab = ({ tier }: GfxTabProps) => {
  const { user } = useUser();
  const firestore = useFirestore();
  const [activeProfile, setActiveProfile] = useState(tier === 'high' ? 'competitive' : 'lagfix');
  const [region, setRegion] = useState('Global');
  const [isPatching, setIsPatching] = useState(false);

  const handleApplyConfig = () => {
    if (!user || !firestore) return;
    setIsPatching(true);

    const configRef = doc(firestore, 'users', user.uid, 'gameSettings', 'global_default');
    const settingsData = {
      gfxProfile: tier === 'high' ? activeProfile : 'lagfix',
      region,
      lastUpdated: new Date().toISOString()
    };
    
    setDoc(configRef, settingsData, { merge: true })
      .finally(() => {
        setTimeout(() => setIsPatching(false), 2000);
      });
  };

  return (
    <div className="space-y-4">
      <div className="space-y-3">
        <div>
          <h2 className="text-xl font-headline font-bold">Graphic Settings</h2>
          <p className="text-[10px] text-muted-foreground uppercase tracking-widest">Unified Engine Optimization</p>
        </div>
        
        <div className="flex gap-1 overflow-x-auto pb-2 custom-scrollbar no-scrollbar">
          {['Global', 'India', 'Korea', 'Taiwan', 'Vietnam'].map(r => (
            <Button 
              key={r}
              variant={region === r ? "default" : "outline"}
              size="sm"
              onClick={() => setRegion(r)}
              className={cn(
                "text-[8px] h-7 px-2.5 font-bold tracking-widest uppercase flex-shrink-0",
                region === r ? "bg-primary border-primary" : "border-white/10"
              )}
            >
              {r}
            </Button>
          ))}
        </div>
      </div>

      {tier === 'high' ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {GFX_PROFILES.map((profile) => (
            <LiquidGlassCard 
              key={profile.id}
              onClick={() => setActiveProfile(profile.id)}
              className={cn(
                "p-4 cursor-pointer transition-all duration-300 flex flex-col items-center text-center",
                activeProfile === profile.id ? "bg-primary/10 border-primary ring-1 ring-primary/20" : "hover:bg-white/10"
              )}
            >
              <profile.icon className={cn("w-6 h-6 mb-2", profile.color)} />
              <h3 className="font-headline font-bold text-[10px] uppercase mb-2 truncate w-full">{profile.name}</h3>
              <div className="w-full space-y-1 opacity-60">
                <div className="flex justify-between text-[7px] uppercase">
                  <span>IQ</span>
                  <span className="font-bold">{profile.graphics}</span>
                </div>
              </div>
            </LiquidGlassCard>
          ))}
        </div>
      ) : (
        <div className="p-8 bg-white/5 border border-primary/20 rounded-[2rem] text-center space-y-4">
          <div className="w-12 h-12 bg-primary/20 rounded-2xl flex items-center justify-center mx-auto border border-primary/40">
            <Lock className="w-6 h-6 text-primary" />
          </div>
          <div className="space-y-1">
             <h3 className="text-lg font-headline font-black text-white uppercase italic">HD STABLE_LOCK</h3>
             <p className="text-[9px] text-muted-foreground uppercase tracking-widest leading-relaxed">System profile detected as {tier}-end.<br/>Optimized for HD Graphics and thermal protection.</p>
          </div>
        </div>
      )}

      <LiquidGlassCard className="p-5">
        <h3 className="font-headline font-bold text-sm mb-3">Settings Configuration</h3>
        <div className="space-y-3">
          <div className="p-3 bg-white/5 rounded-xl border border-white/5">
            <p className="text-[8px] font-bold text-primary uppercase mb-1">Configuration Binary</p>
            <p className="text-[7px] text-muted-foreground font-mono truncate">.../SettingConfig_C.sav</p>
            <div className="mt-2 flex gap-1.5">
              <Badge variant="outline" className="text-[6px] bg-emerald-500/10 text-emerald-400 border-emerald-500/20 py-0">OVERRIDE=1</Badge>
              <Badge variant="outline" className="text-[6px] bg-emerald-500/10 text-emerald-400 border-emerald-500/20 py-0">
                {tier === 'low' ? 'FPS_LOCK=60' : tier === 'mid' ? 'FPS_LOCK=90' : 'FPS_LOCK=MAX'}
              </Badge>
            </div>
          </div>
          
          <Button 
            onClick={handleApplyConfig}
            disabled={isPatching}
            className="w-full bg-primary hover:bg-primary/80 h-12 text-[10px] font-black tracking-[0.2em] shadow-lg shadow-primary/20 italic uppercase"
          >
            {isPatching ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : "APPLY GRAPHIC OVERRIDE"}
          </Button>
        </div>
      </LiquidGlassCard>
    </div>
  );
};
