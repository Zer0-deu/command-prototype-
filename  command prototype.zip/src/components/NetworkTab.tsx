
"use client";

import React, { useState, useEffect } from 'react';
import { LiquidGlassCard } from './LiquidGlassCard';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Wifi, 
  Zap,
  Loader2,
  Lock,
  Smartphone,
  Network
} from 'lucide-react';
import { ResponsiveContainer, AreaChart, Area } from 'recharts';
import { cn } from '@/lib/utils';
import { useUser, useFirestore, useDoc, useMemoFirebase, errorEmitter, FirestorePermissionError } from '@/firebase';
import { doc, setDoc } from 'firebase/firestore';

const generatePingData = () => Array.from({ length: 20 }, (_, i) => ({
  time: i,
  ping: Math.floor(Math.random() * (45 - 38) + 38)
}));

export const NetworkTab = () => {
  const { user } = useUser();
  const firestore = useFirestore();
  const userDocRef = useMemoFirebase(() => (user && firestore ? doc(firestore, 'users', user.uid) : null), [user, firestore]);
  const { data: userProfile } = useDoc(userDocRef);

  const [pingData, setPingData] = useState<{time: number, ping: number}[]>([]);
  const [isBoosting, setIsBoosting] = useState(false);
  const [logs, setLogs] = useState<string[]>([]);
  const [isSyncing, setIsSyncing] = useState(false);

  useEffect(() => {
    if (userProfile?.networkBoostActive !== undefined) {
      setIsBoosting(userProfile.networkBoostActive);
    }
  }, [userProfile]);

  useEffect(() => {
    setPingData(generatePingData());

    const interval = setInterval(() => {
      setPingData(prev => {
        if (prev.length === 0) return generatePingData();
        const base = isBoosting ? 26 : 48;
        const jitter = isBoosting ? 4 : 18;
        return [...prev.slice(1), {
          time: prev.length,
          ping: Math.floor(Math.random() * jitter) + base
        }];
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [isBoosting]);

  const handleBoostToggle = () => {
    if (!userDocRef) return;
    
    const nextState = !isBoosting;
    setIsSyncing(true);

    if (nextState) {
      setLogs([
        "Locking WIFI_LOW_LATENCY_PROFILE",
        "Optimizing 5G/LTE Radio RRC State",
        "Applying TCP BBR Algorithm",
        "Disabling Background Net Scan"
      ]);
    } else {
      setLogs([]);
    }

    setDoc(userDocRef, { networkBoostActive: nextState }, { merge: true })
      .catch(async (err) => {
        const permissionError = new FirestorePermissionError({
          path: userDocRef.path,
          operation: 'write',
          requestResourceData: { networkBoostActive: nextState },
        });
        errorEmitter.emit('permission-error', permissionError);
      })
      .finally(() => {
        setIsSyncing(false);
      });
  };

  if (pingData.length === 0) return null;

  return (
    <div className="space-y-4 animate-in fade-in slide-in-from-bottom-8 duration-700">
      <LiquidGlassCard className="p-5">
        <div className="flex justify-between items-start mb-4">
          <div>
            <h2 className="text-lg font-headline font-bold text-white uppercase italic tracking-tighter">Network Bridge</h2>
            <p className="text-[8px] text-primary uppercase font-black tracking-[0.2em]">Latency Calibration</p>
          </div>
          <div className="text-right">
            <div className="text-3xl font-headline font-black text-primary tracking-tighter italic">
              {pingData[pingData.length - 1].ping}
              <span className="text-[10px] font-bold text-muted-foreground ml-0.5 not-italic opacity-50">MS</span>
            </div>
          </div>
        </div>

        <div className="h-24 w-full opacity-70">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={pingData}>
              <defs>
                <linearGradient id="pingGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#06b6d4" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <Area 
                type="monotone" 
                dataKey="ping" 
                stroke="#06b6d4" 
                fill="url(#pingGrad)" 
                strokeWidth={2} 
                isAnimationActive={false}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        <div className="grid grid-cols-2 gap-3 mt-4">
          <div className="p-3 bg-white/5 rounded-xl border border-white/5 text-center">
            <p className="text-[7px] text-muted-foreground uppercase font-bold mb-1">Jitter</p>
            <p className="text-sm font-headline font-bold text-white italic">{isBoosting ? "0.8ms" : "4.2ms"}</p>
          </div>
          <div className="p-3 bg-white/5 rounded-xl border border-white/5 text-center">
            <p className="text-[7px] text-muted-foreground uppercase font-bold mb-1">Packet Loss</p>
            <p className="text-sm font-headline font-bold text-emerald-400 italic">0.0%</p>
          </div>
        </div>
      </LiquidGlassCard>

      <LiquidGlassCard className="p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-headline font-black text-xs flex items-center gap-2 tracking-[0.1em] uppercase text-white italic">
            <Network className="w-3.5 h-3.5 text-primary" />
            Stabilizer Control
          </h3>
          {isBoosting && <Badge className="bg-emerald-500/20 text-emerald-400 border-none text-[7px] font-black italic px-1.5 py-0 animate-pulse">ACTIVE</Badge>}
        </div>

        <div className="space-y-3">
          <div className="flex items-center justify-between p-3 bg-white/5 rounded-xl border border-white/5">
            <div className="flex items-center gap-2">
              <div className="p-1.5 bg-primary/20 rounded-lg">
                <Wifi className="w-3.5 h-3.5 text-primary" />
              </div>
              <div>
                <span className="text-[9px] font-black uppercase block text-white">Wi-Fi Optimization</span>
                <span className="text-[7px] text-muted-foreground uppercase font-bold">LATENCY_LOCK</span>
              </div>
            </div>
            <Lock className="w-3 h-3 text-emerald-400" />
          </div>

          <div className="flex items-center justify-between p-3 bg-white/5 rounded-xl border border-white/5">
            <div className="flex items-center gap-2">
              <div className="p-1.5 bg-emerald-500/20 rounded-lg">
                <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
              </div>
              <div>
                <span className="text-[9px] font-black uppercase block text-white">Radio Boost</span>
                <span className="text-[7px] text-muted-foreground uppercase font-bold">5G DATA STABILITY</span>
              </div>
            </div>
            <Badge variant="outline" className="text-[6px] text-emerald-400 border-emerald-500/20 h-4 font-black py-0">STABLE</Badge>
          </div>

          <Button 
            onClick={handleBoostToggle}
            disabled={isSyncing}
            className={cn(
              "w-full h-14 font-headline font-black tracking-[0.3em] text-[10px] rounded-xl transition-all shadow-lg italic uppercase",
              isBoosting 
                ? "bg-rose-500/20 text-rose-400 border border-rose-500/30" 
                : "bg-primary text-white shadow-primary/20"
            )}
          >
            {isSyncing ? <Loader2 className="w-4 h-4 animate-spin" /> : isBoosting ? "DISENGAGE" : "ENGAGE NET OPTIMIZER"}
          </Button>

          {logs.length > 0 && (
            <div className="bg-black/40 rounded-xl p-3 font-mono text-[8px] text-primary/70 border border-white/5 animate-in slide-in-from-top-1">
              {logs.map((log, i) => (
                <div key={i} className="flex gap-2 mb-0.5 last:mb-0">
                  <span className="opacity-50 text-emerald-400 font-bold">>></span>
                  {log}
                </div>
              ))}
            </div>
          )}
        </div>
      </LiquidGlassCard>
    </div>
  );
};
