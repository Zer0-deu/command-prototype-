
"use client";

import React, { useState, useEffect } from 'react';
import { 
  Dna, 
  Cpu, 
  Database, 
  Monitor, 
  ShieldAlert,
  Zap,
  Activity
} from 'lucide-react';
import { DeviceTier } from '@/app/page';

interface DeepScanProps {
  onComplete: (tier: DeviceTier) => void;
}

export const DeepScan = ({ onComplete }: DeepScanProps) => {
  const [step, setStep] = useState(0);
  const [progress, setProgress] = useState(0);
  const [logs, setLogs] = useState<string[]>([]);
  const [detectedHardware, setDetectedHardware] = useState({
    ram: "---",
    cpu: "---",
    gpu: "---"
  });

  const scanSteps = [
    { label: "Initializing System Audit", icon: Dna },
    { label: "Polling Hardware Registers", icon: Cpu },
    { label: "Measuring RAM Throughput", icon: Database },
    { label: "Benchmarking GPU Cores", icon: Monitor },
    { label: "Thermal Overhead Analysis", icon: ShieldAlert }
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          clearInterval(timer);
          return 100;
        }
        return prev + 1;
      });
    }, 40);

    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (progress === 20) {
      setStep(1);
      setDetectedHardware(h => ({ ...h, ram: "4096MB LPDDR4X" }));
      addLog("Memory Configuration: VALID");
    }
    if (progress === 40) {
      setStep(2);
      setDetectedHardware(h => ({ ...h, cpu: "8x 2.40GHz Cortex" }));
      addLog("Processor Frequencies Verified");
    }
    if (progress === 60) {
      setStep(3);
      setDetectedHardware(h => ({ ...h, gpu: "Adreno 640 Native" }));
      addLog("Graphic Controller Identified");
    }
    if (progress === 80) {
      setStep(4);
      addLog("Thermal Thresholds Calibrated");
    }
    if (progress === 100) {
      setTimeout(() => {
        const tiers: DeviceTier[] = ['low', 'mid', 'high'];
        const randomTier = tiers[Math.floor(Math.random() * tiers.length)];
        onComplete(randomTier);
      }, 1500);
    }
  }, [progress, onComplete]);

  const addLog = (msg: string) => {
    setLogs(prev => [`> ${msg}`, ...prev.slice(0, 3)]);
  };

  return (
    <div className="fixed inset-0 z-[9999] bg-background flex flex-col items-center justify-center p-8 overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-primary/10 via-transparent to-transparent animate-cyber-pulse" />
      
      <div className="relative w-full max-w-sm space-y-12">
        <div className="text-center space-y-2">
          <h2 className="text-2xl font-headline font-black italic tracking-[0.3em] text-white uppercase">Device Audit</h2>
          <p className="text-[9px] text-primary/60 font-black uppercase tracking-[0.5em] animate-pulse">Scanning Hardware Configuration...</p>
        </div>

        <div className="relative aspect-square flex items-center justify-center">
          <div className="absolute inset-0 border-2 border-primary/20 rounded-full animate-spin [animation-duration:10s]" />
          <div className="absolute inset-4 border border-dashed border-accent/30 rounded-full animate-spin [animation-duration:15s] [animation-direction:reverse]" />
          <div className="absolute inset-0 flex items-center justify-center">
             <div className="w-1/2 h-full bg-primary/5 absolute animate-scan opacity-20" />
          </div>
          
          <div className="z-10 flex flex-col items-center gap-4">
            <Zap className="w-12 h-12 text-primary drop-shadow-[0_0_15px_rgba(6,182,212,0.8)]" />
            <div className="text-4xl font-headline font-black italic text-white">{progress}%</div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="grid grid-cols-3 gap-3">
            {[
              { label: 'RAM', val: detectedHardware.ram, icon: Database },
              { label: 'CPU', val: detectedHardware.cpu, icon: Cpu },
              { label: 'GPU', val: detectedHardware.gpu, icon: Monitor }
            ].map((item, i) => (
              <div key={i} className="bg-white/5 border border-white/10 rounded-2xl p-3 text-center space-y-1">
                <item.icon className="w-3 h-3 mx-auto text-primary/40" />
                <p className="text-[6px] text-muted-foreground uppercase font-black">{item.label}</p>
                <p className="text-[8px] font-bold text-white truncate italic">{item.val}</p>
              </div>
            ))}
          </div>

          <div className="space-y-3">
            <div className="flex justify-between items-center px-1">
              <span className="text-[8px] font-black text-primary uppercase italic tracking-widest">{scanSteps[step].label}</span>
              <Activity className="w-3 h-3 text-emerald-500 animate-pulse" />
            </div>
            <div className="h-1.5 bg-white/5 rounded-full overflow-hidden border border-white/5">
              <div 
                className="h-full bg-primary shadow-[0_0_15px_#06b6d4] transition-all duration-300" 
                style={{ width: `${progress}%` }} 
              />
            </div>
          </div>

          <div className="bg-black/60 rounded-2xl p-4 font-mono text-[9px] text-emerald-400/70 border border-white/5 min-h-[80px] leading-relaxed italic">
            {logs.map((log, i) => (
              <div key={i} className="animate-in slide-in-from-left-2 fade-in duration-300">
                {log}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
