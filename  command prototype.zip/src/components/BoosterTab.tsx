
"use client";

import React, { useState, useEffect } from 'react';
import { LiquidGlassCard } from './LiquidGlassCard';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { 
  Zap, 
  Flame, 
  Cpu, 
  Thermometer, 
  Trash2, 
  ShieldAlert,
  FileText,
  Activity,
  Battery,
  Database,
  BarChart3
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useUser, useFirestore, errorEmitter, FirestorePermissionError, type SecurityRuleContext } from '@/firebase';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { useToast } from '@/hooks/use-toast';

export const BoosterTab = () => {
  const { user } = useUser();
  const firestore = useFirestore();
  const { toast } = useToast();
  const [ramUsage, setRamUsage] = useState(42);
  const [cpuTemp, setCpuTemp] = useState(38);
  const [batteryHealth, setBatteryHealth] = useState(94);
  const [storageIO, setStorageIO] = useState(1200);
  const [isCleaning, setIsCleaning] = useState(false);
  const [boostMode, setBoostMode] = useState('performance');
  const [isExporting, setIsExporting] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setCpuTemp(prev => Number((prev + (Math.random() - 0.5) * 0.2).toFixed(1)));
      setStorageIO(prev => Math.floor(1150 + Math.random() * 100));
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  const handleClean = () => {
    setIsCleaning(true);
    setTimeout(() => {
      setRamUsage(28);
      setIsCleaning(false);
      toast({
        title: "SYSTEM OPTIMIZED",
        description: "Background resources released. Performance priorities reset.",
      });
    }, 1500);
  };

  const handleExportLogs = () => {
    if (!user || !firestore) return;
    setIsExporting(true);
    
    const logsColRef = collection(firestore, 'users', user.uid, 'performanceLogs');
    const logData = {
      timestamp: serverTimestamp(),
      avgFps: boostMode === 'extreme' ? 144 : 120,
      avgTemp: cpuTemp,
      avgPing: 32,
      gameName: "Performance Sync",
      logData: `Mode: ${boostMode}\nRAM: ${ramUsage}%\nIO Speed: ${storageIO} MB/s`
    };

    addDoc(logsColRef, logData)
      .then(() => {
        toast({
          title: "LOGS SAVED",
          description: "Performance metrics exported to cloud storage.",
        });
      })
      .catch(async (err) => {
        const permissionError = new FirestorePermissionError({
          path: logsColRef.path,
          operation: 'create',
          requestResourceData: logData,
        } satisfies SecurityRuleContext);
        errorEmitter.emit('permission-error', permissionError);
      })
      .finally(() => {
        setIsExporting(false);
      });
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-left-8 duration-700 pb-24">
      <div className="grid grid-cols-2 gap-4">
        <LiquidGlassCard className="p-6 flex flex-col justify-between h-32 group hover:shadow-[0_0_20px_rgba(6,182,212,0.2)]">
          <div className="flex justify-between items-start">
            <p className="text-[9px] text-muted-foreground uppercase font-black tracking-[0.2em] italic">RAM Usage</p>
            <Cpu className="w-4 h-4 text-primary animate-pulse" />
          </div>
          <div>
             <h3 className="text-2xl font-headline font-black text-primary italic">{ramUsage}%</h3>
             <Progress value={ramUsage} className="h-1.5 mt-2 bg-white/5 border border-white/5" />
          </div>
        </LiquidGlassCard>

        <LiquidGlassCard className="p-6 flex flex-col justify-between h-32 group hover:shadow-[0_0_20px_rgba(244,63,94,0.2)]">
          <div className="flex justify-between items-start">
            <p className="text-[9px] text-muted-foreground uppercase font-black tracking-[0.2em] italic">Processor Heat</p>
            <Thermometer className="w-4 h-4 text-rose-500" />
          </div>
          <div>
            <h3 className="text-2xl font-headline font-black text-rose-500 italic">{cpuTemp}°C</h3>
            <div className="mt-3 flex gap-1 h-1.5">
              {[...Array(12)].map((_, i) => (
                <div key={i} className={cn(
                  "flex-1 rounded-full shadow-inner",
                  i < 8 ? "bg-emerald-500/60" : "bg-rose-500/60"
                )} />
              ))}
            </div>
          </div>
        </LiquidGlassCard>
      </div>

      <LiquidGlassCard className="p-6 grid grid-cols-2 gap-6">
        <div className="space-y-2 border-r border-white/5 pr-4">
          <div className="flex items-center gap-3 mb-1">
            <Battery className="w-4 h-4 text-emerald-400" />
            <p className="text-[9px] text-muted-foreground uppercase font-black tracking-widest italic">Health</p>
          </div>
          <p className="text-xl font-headline font-black text-white italic">{batteryHealth}%</p>
          <Badge variant="outline" className="text-[7px] text-emerald-400 border-emerald-500/30 px-2 py-0 uppercase">Optimal</Badge>
        </div>
        <div className="space-y-2 pl-2">
          <div className="flex items-center gap-3 mb-1">
            <Database className="w-4 h-4 text-primary" />
            <p className="text-[9px] text-muted-foreground uppercase font-black tracking-widest italic">IO Bandwidth</p>
          </div>
          <p className="text-xl font-headline font-black text-white italic">{storageIO}<span className="text-[8px] ml-1 opacity-40">MB/s</span></p>
          <Badge variant="outline" className="text-[7px] text-primary border-primary/30 px-2 py-0 uppercase">NVMe_SSD</Badge>
        </div>
      </LiquidGlassCard>

      <LiquidGlassCard className="p-8">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <div className="p-2.5 bg-primary/20 rounded-xl shadow-lg">
              <Activity className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h3 className="text-[12px] font-black uppercase tracking-[0.4em] italic text-white leading-tight">System Manager</h3>
              <p className="text-[8px] text-primary/60 font-black uppercase tracking-[0.2em]">Hardware Resource Thresholds</p>
            </div>
          </div>
          <Badge variant="outline" className="text-[8px] bg-emerald-500/15 text-emerald-400 border-emerald-500/40 px-3 py-1 font-black italic shadow-inner">
            STABLE
          </Badge>
        </div>
        
        <div className="grid grid-cols-3 gap-3">
          {[
            { id: 'balanced', name: 'Safe', icon: ShieldAlert, color: 'text-emerald-400' },
            { id: 'performance', name: 'Perf', icon: Zap, color: 'text-primary' },
            { id: 'extreme', name: 'EXT', icon: Flame, color: 'text-rose-500' }
          ].map((mode) => (
            <button
              key={mode.id}
              onClick={() => setBoostMode(mode.id)}
              className={cn(
                "p-4 rounded-[1.5rem] border flex flex-col items-center gap-3 transition-all duration-500",
                boostMode === mode.id 
                  ? "bg-primary text-background border-primary shadow-[0_10px_25px_rgba(6,182,212,0.4)] scale-105" 
                  : "bg-white/5 border-white/10 text-muted-foreground hover:bg-white/10"
              )}
            >
              <mode.icon className={cn("w-6 h-6 transition-transform", boostMode === mode.id ? "scale-110" : mode.color)} />
              <span className={cn("text-[9px] font-black uppercase tracking-[0.3em] italic", boostMode === mode.id ? "text-background" : "opacity-60")}>{mode.name}</span>
            </button>
          ))}
        </div>
      </LiquidGlassCard>

      <div className="space-y-4">
        <LiquidGlassCard className="p-8 flex flex-col gap-6 text-center bg-primary/5 border-primary/20 relative group hover:shadow-[0_0_40px_rgba(6,182,212,0.1)]">
          <div className="flex flex-col items-center relative z-10">
            <div className="w-16 h-16 bg-primary/20 rounded-[1.5rem] flex items-center justify-center mb-4 shadow-lg border border-primary/30 group-hover:scale-110 transition-transform duration-700">
              <Trash2 className="w-8 h-8 text-primary" />
            </div>
            <h3 className="text-lg font-headline font-black uppercase italic tracking-tighter text-white">System Purge</h3>
            <p className="text-[9px] text-muted-foreground px-6 uppercase tracking-[0.2em] font-bold leading-relaxed mt-2">Force clear active memory and system caches</p>
          </div>
          
          <Button 
            onClick={handleClean}
            disabled={isCleaning}
            className="w-full h-16 bg-primary hover:bg-primary/80 text-[11px] font-black tracking-[0.5em] rounded-[1.5rem] transition-all italic uppercase shadow-xl shadow-primary/20 hover:translate-y-[-2px] active:translate-y-0"
          >
            {isCleaning ? "OPTIMIZING..." : "EXECUTE MEMORY PURGE"}
          </Button>
        </LiquidGlassCard>

        <div className="grid grid-cols-2 gap-4">
          <LiquidGlassCard className="p-6 text-center group hover:bg-primary/5 transition-all">
            <div className="p-2 bg-primary/10 rounded-xl w-fit mx-auto mb-4 group-hover:scale-110 transition-transform">
              <FileText className="w-5 h-5 text-primary" />
            </div>
            <Button 
              onClick={handleExportLogs}
              disabled={isExporting}
              variant="outline"
              className="w-full h-10 border-primary/30 text-primary text-[9px] tracking-[0.3em] font-black rounded-xl hover:bg-primary/20 italic"
            >
              {isExporting ? "EXPORTING..." : "EXPORT"}
            </Button>
          </LiquidGlassCard>

          <LiquidGlassCard className="p-6 text-center group hover:bg-emerald-500/5 transition-all">
            <div className="p-2 bg-emerald-500/10 rounded-xl w-fit mx-auto mb-4 group-hover:scale-110 transition-transform">
              <BarChart3 className="w-5 h-5 text-emerald-400" />
            </div>
            <Button 
              variant="outline"
              className="w-full h-10 border-emerald-500/30 text-emerald-400 text-[9px] tracking-[0.3em] font-black rounded-xl hover:bg-emerald-500/20 italic"
            >
              LOGS
            </Button>
          </LiquidGlassCard>
        </div>
      </div>
    </div>
  );
};
