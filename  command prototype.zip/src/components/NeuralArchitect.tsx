'use client';

import React, { useState, useRef } from 'react';
import { LiquidGlassCard } from './LiquidGlassCard';
import { 
  BrainCircuit, 
  Loader2, 
  CheckCircle2, 
  Zap, 
  Activity, 
  Dna, 
  Volume2, 
  VolumeX, 
  Globe, 
  UserCircle,
  Cpu,
  ShieldCheck
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { optimizeSystem, type OptimizeSystemOutput } from '@/ai/flows/optimize-system-flow';
import { useUser, useFirestore, useDoc, useMemoFirebase } from '@/firebase';
import { doc } from 'firebase/firestore';
import { cn } from '@/lib/utils';

const VOICES = [
  { id: 'Algenib', name: 'Algenib (Command)' },
  { id: 'Achernar', name: 'Achernar (Tactical)' },
  { id: 'Pherkad', name: 'Pherkad (Processor)' },
] as const;

const PERSONALITIES = [
  { id: 'Command', name: 'Command Mode' },
  { id: 'Tactical', name: 'Tactical Analyst' },
  { id: 'Zen', name: 'Zen Flow' },
] as const;

const LANGUAGES = [
  { id: 'English', name: 'English' },
  { id: 'Korean', name: 'Korean' },
  { id: 'Japanese', name: 'Japanese' },
  { id: 'Vietnamese', name: 'Vietnamese' },
] as const;

export const NeuralArchitect = () => {
  const { user } = useUser();
  const firestore = useFirestore();
  const userDocRef = useMemoFirebase(() => (user && firestore ? doc(firestore, 'users', user.uid) : null), [user, firestore]);
  const { data: userProfile } = useDoc(userDocRef);

  const [isOptimizing, setIsOptimizing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [aiResponse, setAiResponse] = useState<OptimizeSystemOutput | null>(null);
  const [selectedVoice, setSelectedVoice] = useState<typeof VOICES[number]['id']>('Algenib');
  const [selectedPersonality, setSelectedPersonality] = useState<typeof PERSONALITIES[number]['id']>('Command');
  const [selectedLanguage, setSelectedLanguage] = useState<typeof LANGUAGES[number]['id']>('English');
  const [isPlaying, setIsPlaying] = useState(false);
  
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const handleStart = async () => {
    setIsOptimizing(true);
    setProgress(0);
    setAiResponse(null);
    setIsPlaying(false);

    const pInterval = setInterval(() => {
      setProgress(prev => (prev < 90 ? prev + 1.2 : prev));
    }, 60);

    try {
      const response = await optimizeSystem({
        deviceName: userProfile?.deviceName || "Neural Core Prototype",
        currentFps: 112,
        targetFps: userProfile?.targetHz || 120,
        thermalStatus: 42,
        voiceName: selectedVoice,
        personality: selectedPersonality,
        language: selectedLanguage,
      });
      
      clearInterval(pInterval);
      setProgress(100);
      setAiResponse(response);
      
      if (response.audioUri && audioRef.current) {
        setTimeout(() => {
          audioRef.current?.play();
          setIsPlaying(true);
        }, 500);
      }
    } catch (error) {
      console.error('Neural Architect Calibration Failure:', error);
    } finally {
      setIsOptimizing(false);
    }
  };

  const toggleAudio = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
      } else {
        audioRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-12 duration-700">
      <LiquidGlassCard className="p-8 flex flex-col gap-6 shadow-[0_0_50px_rgba(6,182,212,0.1)]">
        <div className="flex flex-col gap-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-primary/20 rounded-2xl border border-primary/40 shadow-[0_0_20px_rgba(6,182,212,0.3)]">
                <BrainCircuit className="w-8 h-8 text-primary animate-float" />
              </div>
              <div>
                <h2 className="text-2xl font-headline font-black italic tracking-tighter uppercase text-white">Architect</h2>
                <p className="text-[9px] text-primary/70 uppercase tracking-[0.4em] font-black italic opacity-80">Neural Companion v4.5</p>
              </div>
            </div>
            {aiResponse?.audioUri && (
              <button 
                onClick={toggleAudio}
                className="flex items-center gap-2 px-4 py-2 bg-primary/20 border border-primary/40 rounded-2xl hover:bg-primary/30 transition-all active:scale-95 shadow-lg"
              >
                {isPlaying ? <Volume2 className="w-4 h-4 text-primary animate-pulse" /> : <VolumeX className="w-4 h-4 text-primary" />}
                <span className="text-[9px] font-black text-primary uppercase tracking-widest italic">Neural Feedback</span>
                <audio 
                  ref={audioRef} 
                  src={aiResponse.audioUri} 
                  onEnded={() => setIsPlaying(false)}
                  className="hidden"
                />
              </button>
            )}
          </div>

          <div className="grid grid-cols-3 gap-2">
            <div className="space-y-1.5">
              <label className="text-[7px] font-black uppercase tracking-[0.2em] text-muted-foreground ml-1">Personality</label>
              <Select value={selectedPersonality} onValueChange={(v: any) => setSelectedPersonality(v)}>
                <SelectTrigger className="w-full h-9 text-[8px] font-black uppercase tracking-widest bg-white/5 border-white/10 rounded-xl">
                  <ShieldCheck className="w-3 h-3 mr-1.5 text-primary/70" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-neutral-900 border-white/10 text-[9px] font-black uppercase tracking-widest">
                  {PERSONALITIES.map(p => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-1.5">
              <label className="text-[7px] font-black uppercase tracking-[0.2em] text-muted-foreground ml-1">Voice Profile</label>
              <Select value={selectedVoice} onValueChange={(v: any) => setSelectedVoice(v)}>
                <SelectTrigger className="w-full h-9 text-[8px] font-black uppercase tracking-widest bg-white/5 border-white/10 rounded-xl">
                  <UserCircle className="w-3 h-3 mr-1.5 text-primary/70" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-neutral-900 border-white/10 text-[9px] font-black uppercase tracking-widest">
                  {VOICES.map(v => <SelectItem key={v.id} value={v.id}>{v.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-1.5">
              <label className="text-[7px] font-black uppercase tracking-[0.2em] text-muted-foreground ml-1">Locale</label>
              <Select value={selectedLanguage} onValueChange={(v: any) => setSelectedLanguage(v)}>
                <SelectTrigger className="w-full h-9 text-[8px] font-black uppercase tracking-widest bg-white/5 border-white/10 rounded-xl">
                  <Globe className="w-3 h-3 mr-1.5 text-primary/70" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-neutral-900 border-white/10 text-[9px] font-black uppercase tracking-widest">
                  {LANGUAGES.map(l => <SelectItem key={l.id} value={l.id}>{l.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        <div className="flex-1 bg-black/50 backdrop-blur-3xl rounded-[2.5rem] p-8 font-mono text-[11px] border border-white/10 min-h-[450px] leading-relaxed relative shadow-inner overflow-hidden">
          <div className="absolute top-0 right-0 p-8 opacity-5 pointer-events-none">
            <Dna className="w-32 h-32 animate-pulse" />
          </div>

          {!isOptimizing && !aiResponse && (
            <div className="flex flex-col items-center justify-center h-full text-center p-8 gap-8 animate-in zoom-in-95 duration-700">
              <div className="relative w-28 h-28 flex items-center justify-center">
                <div className="absolute inset-0 border-2 border-dashed border-primary/30 rounded-full animate-spin [animation-duration:12s]" />
                <Activity className="w-12 h-12 text-primary/40 animate-pulse" />
              </div>
              <div className="space-y-3">
                <p className="text-muted-foreground text-sm font-medium tracking-tight">Neural Link: Standby</p>
                <p className="text-[9px] opacity-60 uppercase tracking-[0.6em] font-black italic text-primary">Synchronizing hardware signatures...</p>
              </div>
              <Button 
                onClick={handleStart} 
                className="bg-primary hover:bg-primary/80 text-background rounded-[2rem] px-12 h-16 uppercase tracking-[0.4em] font-black text-[11px] italic shadow-[0_15px_30px_rgba(6,182,212,0.4)] transition-all hover:scale-105 active:scale-95"
              >
                Engage Architect
              </Button>
            </div>
          )}

          {isOptimizing && (
            <div className="space-y-12 pt-20 animate-in fade-in duration-500">
              <div className="flex flex-col items-center gap-8">
                <div className="relative">
                  <Loader2 className="w-20 h-20 text-primary animate-spin" />
                  <div className="absolute inset-0 border-4 border-primary/10 rounded-full scale-125" />
                </div>
                <div className="text-center">
                  <p className="text-primary animate-pulse uppercase tracking-[0.8em] font-black text-[11px] italic">Calibrating Companion Personality...</p>
                  <p className="text-[8px] text-muted-foreground uppercase font-black tracking-[0.4em] mt-2 opacity-50">Mapping Audio Neural Buffers</p>
                </div>
              </div>
              <div className="space-y-4 max-w-xs mx-auto">
                <div className="flex justify-between text-[10px] text-muted-foreground uppercase font-black tracking-widest px-2 italic">
                  <span>Neural_Synapse</span>
                  <span className="text-primary">{Math.floor(progress)}%</span>
                </div>
                <div className="h-2 bg-white/5 rounded-full overflow-hidden border border-white/5 p-0.5">
                  <div className="h-full bg-primary shadow-[0_0_20px_#06b6d4] transition-all duration-300 rounded-full" style={{ width: `${progress}%` }} />
                </div>
              </div>
            </div>
          )}

          {aiResponse && (
            <div className="space-y-8 animate-in slide-in-from-bottom-8 fade-in duration-700 h-full overflow-y-auto custom-scrollbar pr-3">
              <div className="flex items-center justify-between border-b border-white/10 pb-5">
                <div className="flex items-center gap-4 text-emerald-400 font-black uppercase tracking-[0.4em] text-[10px] italic">
                  <CheckCircle2 className="w-5 h-5 shadow-[0_0_15px_#10b981]" />
                  Neural Handshake Complete
                </div>
                <div className="flex gap-1 h-4">
                  {isPlaying && [...Array(5)].map((_, i) => (
                    <div key={i} className="w-1 bg-primary rounded-full animate-pulse" style={{ animationDelay: `${i * 0.15}s` }} />
                  ))}
                </div>
              </div>
              
              <div className="p-7 bg-primary/5 rounded-[2.5rem] border border-primary/20 space-y-4 shadow-inner relative group/analysis transition-all hover:bg-primary/10">
                <div className="flex items-center justify-between">
                  <p className="text-primary font-black uppercase text-[10px] tracking-[0.6em] italic">Tactical Briefing</p>
                  <Zap className="w-5 h-5 text-primary/40" />
                </div>
                <p className="text-white/95 leading-relaxed italic text-base tracking-tight leading-snug">
                  "{aiResponse.analysis}"
                </p>
              </div>

              <div className="space-y-4">
                <p className="text-primary font-black uppercase text-[10px] tracking-[0.6em] italic ml-3">Optimizations Applied</p>
                <div className="grid gap-3">
                  {aiResponse.recommendations.map((rec, i) => (
                    <div key={i} className="flex gap-4 items-center p-5 bg-white/5 rounded-[1.5rem] border border-white/10 group hover:bg-primary/10 transition-all shadow-inner">
                      <div className="w-2 h-2 bg-primary rounded-full shadow-[0_0_10px_#06b6d4] shrink-0" />
                      <span className="text-muted-foreground text-[11px] font-black uppercase tracking-wider italic leading-tight group-hover:text-white transition-colors">{rec}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-5 py-4">
                <div className="p-6 bg-black/40 rounded-[2rem] border border-white/10 text-center shadow-inner group hover:border-emerald-500/40 transition-colors">
                  <p className="text-[9px] text-muted-foreground uppercase font-black tracking-widest mb-2">Perf Gain</p>
                  <div className="flex items-center justify-center gap-2">
                    <Activity className="w-4 h-4 text-emerald-400" />
                    <p className="text-3xl font-headline font-black text-emerald-400 italic">+{aiResponse.predictedGain}%</p>
                  </div>
                </div>
                <div className="p-6 bg-black/40 rounded-[2rem] border border-white/10 text-center shadow-inner group hover:border-primary/40 transition-colors">
                  <p className="text-[9px] text-muted-foreground uppercase font-black tracking-widest mb-2">Stability</p>
                  <div className="flex items-center justify-center gap-2">
                    <Cpu className="w-4 h-4 text-primary" />
                    <p className={cn(
                      "text-3xl font-headline font-black italic",
                      aiResponse.safetyRating === 'Safe' ? 'text-emerald-400' : 
                      aiResponse.safetyRating === 'Warning' ? 'text-amber-400' : 'text-rose-400'
                    )}>{aiResponse.safetyRating}</p>
                  </div>
                </div>
              </div>

              <Button 
                onClick={handleStart} 
                variant="outline" 
                className="w-full border-white/10 text-[10px] font-black tracking-[0.5em] text-muted-foreground hover:text-primary hover:border-primary/40 h-16 uppercase rounded-[1.5rem] italic transition-all active:scale-[0.98] mb-8 shadow-inner"
              >
                Recalibrate Neural Companion
              </Button>
            </div>
          )}
        </div>
      </LiquidGlassCard>
    </div>
  );
};
