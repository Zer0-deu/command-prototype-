
"use client";

import React, { useState, useEffect } from 'react';
import { cn } from '@/lib/utils';
import { 
  X,
  Activity,
  Flame,
  Loader2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Badge } from '@/components/ui/badge';
import { useUser, useFirestore, useDoc, useMemoFirebase } from '@/firebase';
import { doc, setDoc } from 'firebase/firestore';
import Image from 'next/image';
import imageData from '@/app/lib/placeholder-images.json';

export const InGameOverlay = () => {
  const { user } = useUser();
  const firestore = useFirestore();
  const userDocRef = useMemoFirebase(() => (user && firestore ? doc(firestore, 'users', user.uid) : null), [user, firestore]);
  const { data: userProfile } = useDoc(userDocRef);

  const [isOpen, setIsOpen] = useState(false);
  const [activeMode, setActiveMode] = useState('Boost');
  const [temp, setTemp] = useState(38);
  const [isRefreshing, setIsRefreshing] = useState(false);

  useEffect(() => {
    if (userProfile?.boostMode) {
      setActiveMode(userProfile.boostMode.charAt(0).toUpperCase() + userProfile.boostMode.slice(1));
    }
  }, [userProfile?.boostMode]);

  useEffect(() => {
    const interval = setInterval(() => {
      setTemp(prev => Number((prev + (Math.random() - 0.5) * 0.1).toFixed(1)));
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  const handleApplyChanges = () => {
    if (!userDocRef) return;
    setIsRefreshing(true);
    
    setDoc(userDocRef, { 
      boostMode: activeMode.toLowerCase(),
      lastOverlayUpdate: new Date().toISOString() 
    }, { merge: true });

    setTimeout(() => {
      setIsRefreshing(false);
      setIsOpen(false);
    }, 600);
  };

  return (
    <>
      <div className="fixed inset-y-0 right-0 z-[1000] pointer-events-none flex items-center max-w-md w-full left-auto">
        <button 
          onClick={() => setIsOpen(!isOpen)}
          className={cn(
            "w-1.5 h-16 bg-primary/30 backdrop-blur-xl rounded-l-full pointer-events-auto transition-all translate-x-0 absolute right-0 group hover:w-2 hover:bg-primary/50",
            isOpen && "opacity-0 translate-x-4"
          )}
        >
          <div className="w-full h-full border-l border-white/20" />
        </button>

        <div className={cn(
          "w-64 h-[70vh] bg-black/95 backdrop-blur-3xl border-l border-primary/20 rounded-l-[2.5rem] pointer-events-auto transition-all duration-500 ease-in-out shadow-[0_0_80px_rgba(0,0,0,0.9)] absolute right-0",
          isOpen ? "translate-x-0" : "translate-x-full"
        )}>
          <div className="p-6 h-full flex flex-col gap-6 overflow-y-auto custom-scrollbar">
            <div className="flex justify-between items-center border-b border-white/5 pb-4">
              <div className="flex items-center gap-3">
                <div className="relative w-4 h-4">
                   <Image 
                    src={imageData['command-logo'].url}
                    alt="COMMAND"
                    fill
                    className="object-contain"
                    data-ai-hint={imageData['command-logo'].hint}
                  />
                </div>
                <h3 className="font-headline font-black text-[10px] tracking-[0.4em] uppercase text-primary italic">COMMAND</h3>
              </div>
              <button onClick={() => setIsOpen(false)} className="p-1 hover:bg-white/5 rounded-lg text-muted-foreground hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="p-3 bg-white/5 rounded-2xl text-center border border-white/5">
                <p className="text-[7px] text-muted-foreground uppercase font-bold tracking-widest mb-1">Thermal</p>
                <p className="text-sm font-black text-rose-400 italic">{temp}°C</p>
              </div>
              <div className="p-3 bg-white/5 rounded-2xl text-center border border-white/5">
                <p className="text-[7px] text-muted-foreground uppercase font-bold tracking-widest mb-1">Target Rate</p>
                <p className="text-sm font-black text-primary italic">{userProfile?.targetHz || 60}Hz</p>
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex justify-between items-center px-1">
                <p className="text-[8px] text-muted-foreground uppercase font-black tracking-[0.2em]">Boost Mode</p>
                <Badge variant="outline" className={cn("text-[6px] border-none px-0", userProfile?.permissions?.shizuku ? "text-emerald-400" : "text-amber-400")}>
                  {userProfile?.permissions?.shizuku ? "VERIFIED_LINK" : "STANDARD"}
                </Badge>
              </div>
              <div className="grid grid-cols-2 gap-2">
                {['Balanced', 'Extreme'].map(mode => (
                  <Button 
                    key={mode}
                    size="sm"
                    variant={activeMode === mode ? "default" : "outline"}
                    onClick={() => setActiveMode(mode)}
                    className={cn(
                      "text-[9px] h-10 font-black uppercase tracking-widest rounded-xl transition-all", 
                      activeMode === mode ? "bg-primary shadow-[0_4px_12px_rgba(6,182,212,0.3)] border-primary" : "border-white/5 bg-white/5"
                    )}
                  >
                    {mode === 'Extreme' && <Flame className="w-3 h-3 mr-1" />}
                    {mode}
                  </Button>
                ))}
              </div>
            </div>

            <div className="space-y-4 py-2">
              <div className="flex justify-between px-1">
                <p className="text-[8px] text-muted-foreground uppercase font-black tracking-[0.2em]">IQ Settings</p>
                <span className="text-[7px] font-bold text-primary uppercase italic">Custom Override</span>
              </div>
              <Slider defaultValue={[75]} max={100} step={25} className="py-2" />
            </div>

            <div className="mt-auto space-y-3">
               <div className="p-4 bg-primary/10 rounded-2xl border border-primary/20 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Activity className="w-4 h-4 text-primary" />
                    <div>
                      <p className="text-[7px] font-black text-primary uppercase">Status</p>
                      <p className="text-xs font-black text-white italic">{isRefreshing ? 'SYNCING...' : 'OPTIMIZED'}</p>
                    </div>
                  </div>
                  <div className="w-2 h-2 bg-emerald-500 rounded-full animate-ping" />
               </div>
               
               <Button 
                onClick={handleApplyChanges}
                disabled={isRefreshing}
                className="w-full bg-primary hover:bg-primary/80 font-black tracking-[0.3em] text-[10px] h-14 rounded-2xl shadow-xl shadow-primary/20 transition-all uppercase italic"
               >
                {isRefreshing ? <Loader2 className="w-4 h-4 animate-spin" /> : "SYNC SETTINGS"}
               </Button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
