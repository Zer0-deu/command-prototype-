
"use client";

import React from 'react';
import { 
  Home, 
  Gamepad2, 
  Layers, 
  Zap,
  Globe
} from 'lucide-react';
import { cn } from '@/lib/utils';

export const NAV_ITEMS = [
  { icon: Home, label: 'Home', id: 'home' },
  { icon: Gamepad2, label: 'Nexus', id: 'games' },
  { icon: Layers, label: 'Engine', id: 'gfx' },
  { icon: Globe, label: 'Net', id: 'net' },
  { icon: Zap, label: 'Flux', id: 'flux' },
];

interface SidebarProps {
  activeTab: string;
  setActiveTab: (id: string) => void;
}

export const Sidebar = ({ activeTab, setActiveTab }: SidebarProps) => {
  return (
    <nav className="fixed bottom-0 left-0 right-0 h-20 bg-black/90 backdrop-blur-3xl border-t border-white/5 flex items-center justify-around px-4 z-50 max-w-md mx-auto shadow-[0_-10px_40px_rgba(0,0,0,0.6)]">
      {NAV_ITEMS.map((item) => (
        <button
          key={item.id}
          onClick={() => setActiveTab(item.id)}
          className={cn(
            "flex flex-col items-center gap-1.5 transition-all duration-500 relative px-2 py-2 rounded-2xl",
            activeTab === item.id 
              ? "text-primary scale-110" 
              : "text-muted-foreground hover:text-white hover:scale-105 active:scale-90"
          )}
        >
          <div className={cn(
            "p-2.5 rounded-xl transition-all duration-500",
            activeTab === item.id && "bg-primary/15 shadow-[inset_0_0_10px_rgba(6,182,212,0.3)]"
          )}>
            <item.icon className={cn("w-5 h-5 transition-transform", activeTab === item.id && "animate-pulse")} />
          </div>
          <span className={cn(
            "text-[8px] font-black uppercase tracking-[0.2em] leading-none transition-all",
            activeTab === item.id ? "opacity-100 italic" : "opacity-40"
          )}>
            {item.label}
          </span>
          {activeTab === item.id && (
            <div className="absolute -top-1 left-1/2 -translate-x-1/2 w-8 h-1 bg-primary rounded-full blur-[2px] shadow-[0_0_10px_#06b6d4]" />
          )}
        </button>
      ))}
    </nav>
  );
};
