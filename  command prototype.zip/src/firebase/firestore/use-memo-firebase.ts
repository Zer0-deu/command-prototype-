
'use client';

import { useRef } from 'react';

/**
 * A specialized hook to stabilize Firebase references and queries.
 * Unlike standard useMemo, this ensures that the reference is only 
 * recreated if the actual dependencies change, preventing infinite loops.
 */
export function useMemoFirebase<T>(factory: () => T, dependencies: any[]): T {
  const ref = useRef<T | null>(null);
  const depsRef = useRef<any[]>([]);

  const changed = 
    dependencies.length !== depsRef.current.length || 
    dependencies.some((dep, i) => dep !== depsRef.current[i]);

  if (changed || ref.current === null) {
    ref.current = factory();
    depsRef.current = dependencies;
  }

  return ref.current;
}
