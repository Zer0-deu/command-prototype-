'use client';

import { initializeApp, getApps, getApp, FirebaseApp } from 'firebase/app';
import { getFirestore, Firestore } from 'firebase/firestore';
import { firebaseConfig } from './config';

export function initializeFirebase() {
  let app: FirebaseApp;
  
  try {
    app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
  } catch (e) {
    app = initializeApp({ projectId: 'apex-demo-project' });
  }

  const firestore = getFirestore(app);
  
  // Auth removed per request
  return { app, firestore, auth: null };
}

export * from './provider';
export * from './client-provider';
export * from './auth/use-user';
export * from './firestore/use-doc';
export * from './firestore/use-collection';
export * from './firestore/use-memo-firebase';
export * from './error-emitter';
export * from './errors';
