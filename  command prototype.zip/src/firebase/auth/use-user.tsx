'use client';

/**
 * Mocked useUser hook to provide guest access after auth removal.
 */
export function useUser() {
  return { 
    user: { 
      uid: 'guest-user', 
      email: 'guest@apex.io',
      displayName: 'Guest Commander'
    }, 
    loading: false 
  };
}
